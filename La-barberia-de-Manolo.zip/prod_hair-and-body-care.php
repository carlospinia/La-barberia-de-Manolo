    <div class="row">
        <div class="col s12 m3">
            <div class="card black white-text">
                <div id="div-img-producto" class="card-image">
                    <img src="imagenes/productos/hair-and-body-care/daily-moisturing-shampoo.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Daily moisturing shampoo</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>


        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image small">
                    <img src="imagenes/productos/hair-and-body-care/power-cleanser-style-remover.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Power cleanser style remover</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>


        <div class="col s12 m3">
            <div class="card black white-text">
                <div id="div-img-producto" class="card-image">
                    <img id="img-producto" src="imagenes/productos/hair-and-body-care/anti-dandruff-sebum-control.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Anti dandruff + sebum control</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image">
                    <img src="imagenes/productos/hair-and-body-care/hairrecovery-shampoo.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Hair recovering + thickening</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image">
                    <img src="imagenes/productos/hair-and-body-care/gray-shampoo.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Gray shampoo</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image">
                    <img src="imagenes/productos/hair-and-body-care/3-in-1.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">3 in 1</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image">
                    <img src="imagenes/productos/hair-and-body-care/24-hour-deodorant-body-wash.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">24 hour deodorant body wash</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image">
                    <img src="imagenes/productos/hair-and-body-care/nine-fragrance.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Nine fragance</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

    </div>