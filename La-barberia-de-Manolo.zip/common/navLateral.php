<ul id="slide-out" class="side-nav transparent" style="margin-top: 85px">
    <li><a href="index.php" class="waves-effect white-text"><i class="material-icons white-text">home</i>Inicio</a></li>
    <li><a href="servicios.php" class="waves-effect white-text"><i class="material-icons white-text"><img
                    src="imagenes/icons/scissors-opened-tool-shape.png" alt=""/></i>Servicios</a></li>
    <li><a href="tendenciasGrid.php" class="waves-effect white-text"><i class="material-icons white-text"><img
                    src="imagenes/icons/young-man-with-modern-hair-cut.png" alt=""/></i>Tendencias</a></li>
    <li><a href="productos.php" class="waves-effect white-text"><i class="material-icons white-text"><img
                    src="imagenes/icons/hair-softener.png" alt=""/></i>Producos</a></li>
    <li><a href="origenes.php" class="waves-effect white-text"><i class="material-icons white-text">today</i>Orígenes</a></li>
    <li><a href="shows.php" class="waves-effect white-text"><i class="material-icons white-text"><img src="imagenes/icons/youtube.png"
                                                                                               alt=""/></i>Shows</a></li>
    <li><a href="equipo.php" class="waves-effect white-text"><i class="material-icons white-text"><img src="imagenes/icons/diploma.png"
                                                                                               alt=""/></i>Equipo</a></li>
    <li><a href="redesSociales.php" class="waves-effect white-text"><i class="material-icons white-text">favorite<img alt=""/></i>Redes sociales</a></li>
</ul>

<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>

<script>
    // Initialize collapse button
    $('.button-collapse').sideNav({
            menuWidth: 200,
            edge: 'right',
           //closeOnClick: true,
        }
    );
</script>
