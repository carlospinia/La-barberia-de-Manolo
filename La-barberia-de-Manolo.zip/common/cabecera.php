<header>
    <nav>
    <div class="nav-wrapper">
      <a href="index.php" class="brand-logo left" style="line-height: 0"><img src="imagenes/cabecera.png" alt=""/></a>
      <a href="#" data-activates="slide-out" class="button-collapse right"><i class="material-icons">menu</i></a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
          <li> <a title="Inicio" href="index.php">Inicio</a> </li>
          <li> <a title="Servicios" href="">Servicios</a> </li>
          <li> <a title="Tendencias" href="tendenciasGrid.php">Tendencias</a> </li>
          <li> <a title="Productos" href="productos.php">Productos</a> </li>
          <li> <a title="Origenes" href="">Origenes</a> </li>
          <li> <a title="Shows" href="">Shows</a> </li>
          <li> <a title="Formación" href="">Formación</a> </li>
      </ul>
    </div>
    </nav>
</header>