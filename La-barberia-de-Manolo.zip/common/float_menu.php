<div class="fixed-action-btn vertical click-to-toggle hide-on-large-only">
    <a class="btn-floating btn-large">
        <i class="material-icons large">view_list</i>
    </a>
    <ul>
        <li>
            <div class="btn-floating chip white">Servicios</div>
            <a class="btn-floating"><i class="material-icons"><img
                            src="imagenes/icons/scissors-opened-tool-shape.png" alt=""/></i></a></li>
        <li>
            <div class="btn-floating chip white">Contacto</div>
            <a class="btn-floating"><i class="material-icons">contact_phone</i></a>
        </li>

        <li><a href="tendenciasGrid.php">
                <div class="btn-floating chip white">Tendencias</div>
                <a href="tendenciasGrid.php" class="btn-floating"><i class="material-icons"><img
                            src="imagenes/icons/young-man-with-modern-hair-cut.png" alt=""/></i>
                </a>
            </a>
        </li>

        <li><a href="productos.php">
                <div class="btn-floating chip white">Productos</div>
                <a href="productos.php" class="btn-floating"><i class="material-icons"><img
                                src="imagenes/icons/hair-softener.png" alt=""/></i>
                </a>
            </a>
        </li>

        <li>
            <div class="btn-floating chip white">Origenes</div>
            <a class="btn-floating"><i class="material-icons">vpn_key</i></a></li>
        <li>
            <div class="btn-floating chip white">Shows</div>
            <a class="btn-floating"><i class="material-icons"><img src="imagenes/icons/youtube.png"
                                                                         alt=""/></i></a></li>
        <li>
            <div class="btn-floating chip white">Formacion</div>
            <a class="btn-floating"><i class="material-icons"><img src="imagenes/icons/diploma.png"
                                                                         alt=""/></i></a></li>
    </ul>
</div>

