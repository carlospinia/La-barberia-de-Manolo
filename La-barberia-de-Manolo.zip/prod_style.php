    <div class="row">

        <div class="col s12 m3">
            <div class="card black white-text">
                <div id="div-img-producto" class="card-image">
                    <img src="imagenes/productos/style/forming-cream.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Forming cream</p>
                    <p class="center-align">I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>


        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image small">
                    <img src="imagenes/productos/style/pomade.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Pomade</p>
                    <p class="center-align">I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>


        <div class="col s12 m3">
            <div class="card black white-text">
                <div id="div-img-producto" class="card-image">
                    <img id="img-producto" src="imagenes/productos/style/heavy_hold_pomade.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Heavy hold pomade</p>
                    <p class="center-align">I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image">
                    <img src="imagenes/productos/style/fiber.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Fiber</p>
                    <p class="center-align">I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image">
                    <img src="imagenes/productos/style/defining-paste.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Defining paste</p>
                    <p class="center-align">I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image">
                    <img src="imagenes/productos/style/light-hold-texture-lotion.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Light hold texture lotion</p>
                    <p class="center-align">I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image">
                    <img src="imagenes/productos/style/molding-clay.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Molding clay</p>
                    <p class="center-align">I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image">
                    <img src="imagenes/productos/style/grooming-cream.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Grooming cream</p>
                    <p class="center-align">I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image">
                    <img src="imagenes/productos/style/alternator.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Alternator</p>
                    <p class="center-align">I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image">
                    <img src="imagenes/productos/style/firm-hold-styling-gel.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Firm hold styling gel</p>
                    <p class="center-align">I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image">
                    <img src="imagenes/productos/style/boost-powder.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Boost powder</p>
                    <p class="center-align">I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

    </div>