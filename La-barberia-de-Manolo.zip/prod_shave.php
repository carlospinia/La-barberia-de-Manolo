    <div class="row">
        <div class="col s12 m3">
            <div class="card black white-text">
                <div id="div-img-producto" class="card-image">
                    <img src="imagenes/productos/shave/moisturizing-shave-cream.jpg">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Moisturizing shave cream</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>


        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image small">
                    <img src="imagenes/productos/shave/post-shave-cooling-lotion.jpg">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Post shave cooling lotion</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>


        <div class="col s12 m3">
            <div class="card black white-text">
                <div id="div-img-producto" class="card-image">
                    <img id="img-producto" src="imagenes/productos/shave/precision-shave-gel.jpg">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Precision shave gel</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image">
                    <img src="imagenes/productos/shave/ultra-gliding-shave-oil.jpg">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Ultra gliding shave oil</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>
    </div>