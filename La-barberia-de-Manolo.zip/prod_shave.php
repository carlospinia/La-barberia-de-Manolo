    <div class="row">

        <div class="col s12 m3">
            <div class="card black white-text">
                <div id="div-img-producto" class="card-image">
                    <img src="imagenes/productos/shave/shave-oil.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Shave oil</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>


        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image small">
                    <img src="imagenes/productos/shave/shave-cream-moisturicing.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Shave cream moisturicing</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>


        <div class="col s12 m3">
            <div class="card black white-text">
                <div id="div-img-producto" class="card-image">
                    <img id="img-producto" src="imagenes/productos/shave/all-in-one.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">All in one</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image">
                    <img src="imagenes/productos/shave/revitalizing-toner.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Revitalicing toner</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image">
                    <img src="imagenes/productos/shave/beard-serum.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Beard serum</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

        <div class="col s12 m3">
            <div class="card black white-text">
                <div class="card-image">
                    <img src="imagenes/productos/shave/aceite-shave-and-co.png">
                </div>
                <div class="card-content black white-text">
                    <p class="card-title center-align">Aceite shave and co</p>
                    <p>I am a very simple card. I am good at containing small bits of information.
                        I am convenient because I require little markup to use effectively.</p>
                </div>
            </div>
        </div>

    </div>