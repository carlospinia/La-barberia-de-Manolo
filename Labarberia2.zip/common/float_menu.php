<div class="fixed-action-btn vertical click-to-toggle hide-on-large-only">
    <a class="btn-floating btn-large green">
        <i class="material-icons large">view_list</i>
    </a>
    <ul>
        <li>
            <div class="btn-floating chip">Servicios</div>
            <a class="btn-floating green"><i class="material-icons"><img
                            src="imagenes/icons/scissors-opened-tool-shape.png" alt=""/></i></a></li>
        <li>
            <div class="btn-floating chip">Contacto</div>
            <a class="btn-floating green"><i class="material-icons">contact_phone</i></a></li>
        <li>
            <div class="btn-floating chip">Tendencias</div>
            <a class="btn-floating green"><i class="material-icons"><img
                            src="imagenes/icons/young-man-with-modern-hair-cut.png" alt=""/></i></a></li>
        <li><a href="productos.php">
                <div href="productos.php" class="btn-floating chip">Productos</div>
                <a href="productos.php" class="btn-floating green"><i class="material-icons"><img
                                src="imagenes/icons/hair-softener.png" alt=""/></i>
                </a>
            </a>
        </li>

        <li>
            <div class="chip btn-floating">Origenes</div>
            <a class="btn-floating green"><i class="material-icons">vpn_key</i></a></li>
        <li>
            <div class="chip btn-floating">Shows</div>
            <a class="btn-floating green"><i class="material-icons"><img src="imagenes/icons/youtube.png"
                                                                         alt=""/></i></a></li>
        <li>
            <div class="chip btn-floating">Formacion</div>
            <a class="btn-floating green"><i class="material-icons"><img src="imagenes/icons/diploma.png"
                                                                         alt=""/></i></a></li>
    </ul>
</div>

