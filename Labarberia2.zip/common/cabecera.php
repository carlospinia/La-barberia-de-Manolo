<header>
    <nav>
    <div class="nav-wrapper">
      <a href="index.php" class="brand-logo"><img src="imagenes/cabecera.png" alt=""/></a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
            <li> <a title="Servicios" href="">Servicios</a> </li>
            <li> <a title="Contacto" href="">Contacto</a> </li>
            <li> <a title="Tendencias" href="">Tendencias</a> </li>
            <li> <a title="Productos" href="productos.php">Productos</a> </li>
            <li> <a title="Origenes" href="">Origenes</a> </li>
            <li> <a title="Shows" href="">Shows</a> </li>
            <li> <a title="Formación" href="">Formación</a> </li>
      </ul>
    </div>
  </nav>
</header><!-- / #main-header -->